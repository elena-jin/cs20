import express from "express";
import { MongoClient } from "mongodb";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const uri = process.env.MONGODB_URI;
const dbName = process.env.DB_NAME || "Stock";
const collName = process.env.COLLECTION_NAME || "PublicCompanies";
const port = process.env.PORT || 3000;

if (!uri) {
  console.error("Missing MONGODB_URI in .env");
  process.exit(1);
}

const client = new MongoClient(uri);
await client.connect();
const db = client.db(dbName);
const coll = db.collection(collName);

const app = express();
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.static(path.join(__dirname, "public")));

app.get("/", (req, res) => {
  res.render("home");
});

app.get("/process", async (req, res) => {
  const q = (req.query.q || "").trim();
  const type = req.query.type || "company"; // "company" or "ticker"

  if (!q) {
    return res.render("results", { query: q, type, results: [], message: "No query provided" });
  }

  // Build search
  let filter;
  if (type === "ticker") {
    // exact match (case-insensitive)
    filter = { ticker: { $regex: `^${escapeRegExp(q)}$`, $options: "i" } };
  } else {
    // company: search substring case-insensitive
    filter = { name: { $regex: escapeRegExp(q), $options: "i" } };
  }

  const results = await coll.find(filter).toArray();

  // log to server console as required
  console.log(`Search by ${type}: "${q}" -> ${results.length} matches`);
  results.forEach((r) => console.log(JSON.stringify({ name: r.name, ticker: r.ticker, price: r.price })));

  // if user requested live price extra-credit integration, you could fetch here (see extra-credit section).
  res.render("results", { query: q, type, results, message: null });
});

// simp helper to escape regex user input
function escapeRegExp(string) {
  return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

app.listen(port, () => {
  console.log(`App listening on port ${port}`);
});
